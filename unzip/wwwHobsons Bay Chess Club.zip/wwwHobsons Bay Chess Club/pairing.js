document.write ('<h3>Pairings:</h3><a id="rd-btn" class="btn btn-primary btn-sm" href="pairs1.html"> 1 </a> <a id="rd-btn" class="btn btn-primary btn-sm" href="pairs2.html"> 2 </a> ')
